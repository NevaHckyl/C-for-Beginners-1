for (int i= 0; < 5; i++)
{
    if (i == 3)
    {
        Console.WriteLine(i);
    }
}
