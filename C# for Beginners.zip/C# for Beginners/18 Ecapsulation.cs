Console.WriteLine("hello opp");
public class Person
{
    public string firstname;
    
    public string lastname;
    
    public DateTime birthday;
    
}