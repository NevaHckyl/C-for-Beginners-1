decimal a = 42.1M;
decimal b = 38.2M;
decimal c = a + b;
Console.WriteLine($"The answer for this is {c}");
