int counter = 0;
do
{
    counter++;
    Console.WriteLine(counter);
}
while (counter < 5);
