using System;

namespace MyNamespace
{
    public class MyApp{
        public static void Main ()
        {
            Console.WriteLine("hello");
        }
    }
}