Console.WriteLine("Hello, David!");

string firstFriend = "       Maria      ";
firstFriend = firstFriend.Trim();
        
string secondFriend = "        Scott       ";
        
Console.WriteLine($"My friends are {firstFriend} and {secondFriend.Trim()}");
